package projet.spring.entities;


public @interface JsonIgnor {

}